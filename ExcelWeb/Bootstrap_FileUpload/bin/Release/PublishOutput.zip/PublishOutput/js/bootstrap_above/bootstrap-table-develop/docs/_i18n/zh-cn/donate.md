Bootstrap Table 是我个人利用业余时间制作的免费插件。

如果在你的项目中 Bootstrap Table 帮助到了你，可以对 Bootstrap Table 进行捐助。

相信有了你的帮助，Bootstrap Table 一定会继续努力做得更好。